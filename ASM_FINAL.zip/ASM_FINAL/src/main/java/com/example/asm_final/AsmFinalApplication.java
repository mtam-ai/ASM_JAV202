package com.example.asm_final;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsmFinalApplication {

    public static void main(String[] args) {
        SpringApplication.run(AsmFinalApplication.class, args);
    }

}
