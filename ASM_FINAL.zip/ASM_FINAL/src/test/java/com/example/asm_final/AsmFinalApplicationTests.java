package com.example.asm_final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsmFinalApplicationTests {

    @Test
    void contextLoads() {
    }

}
